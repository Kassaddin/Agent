# Elevated Rights Protocol

[Documentation index](<path to docs index>) ·
[Operating rules](<path to operating rules>) ·
[Glossary](<path to glossary>#temporary-elevated-rights) ·
[Decision record](<path to decisions.md>)

This protocol lets the user give the single task-owning agent temporary,
task-scoped permission to work through an agreed task with fewer prompts. It
reduces only the prompts caused by this project's own `ask` gates. It never
widens the [access policy](<path to access policy>), the
[operating rules](<path to operating rules>), or the assistant host's own
controls.

## Who is elevated

- The protocol elevates the **single task-owning agent** for the declared task
  and resources.
- Orchestrator workers keep the kit's per-worker grant described in the
  [worker contract](<path to kit worker contract>#temporary-elevated-rights-and-protected-actions).
  It applies to one identified worker, assignment, and declared resource set, and
  is not master elevation. The limits below apply to workers too.
- A worker grant does not elevate the master, and this protocol does not widen a
  worker's grant.

## Activation and duration

- Start only on an explicit user `elevated rights` command that names the task.
  It may name paths; otherwise the declared resources are those the task needs.
  An agreed Refine baseline or task brief does not activate the protocol.
- The protocol exists in the conversation only. Never write it to the access
  policy, a checkpoint, or another persistent record as active, and never
  rebuild it from a summary or checkpoint.
- It ends when the named task completes or stops, when the user revokes it, or
  when the conversation ends. A later task, session, or resumed conversation
  needs a new command.
- At activation, state the task and resources in the reply so the scope is
  visible.

## Covered actions

Inside the declared task, with the protocol active, do not ask before:

- reading and searching permitted sources;
- creating and editing files inside the declared resources;
- running the <named validation commands> that the operating rules allow;
- <live runs through protected execution commands>, where the project defines
  them and its operating rules otherwise require a scoped execution approval.

Activation supplies the scoped execution approval that the operating rules
otherwise require for these runs. Their technical contracts stay in force.
Covered runs can change shared state, so name them in the change-set
notification.

## Limited fields

Each of these still needs specific authorization, even with the protocol
active:

- file or folder deletion;
- dependency installs and network downloads;
- <governance files>: the entry guide, the operating rules, the access policy,
  and the installed kit folder;
- CI and repository automation configuration;
- scope expansion and unresolved substantive decisions;
- <project failure gate>, where the project defines an approval step before a
  failure fix;
- environment files, credentials, and secrets.

A project may add fields; it may not remove any.

## Never changed by the protocol

The protocol cannot override any of the following:

- `never` and `user_only` rules, including every local or remote version-control
  mutation;
- secret and authentication sources, the version-control internals, and every
  read-only source;
- the kit's protected actions and any widening of persistent trust or access
  policy; amendments go through Init with a concrete reviewed preview;
- remote writes;
- unavailable access;
- the assistant host's platform prompts and security restrictions.

## Prompting inside an active protocol

- One scoped authorization at activation covers the declared task.
- Notify the user of the change set, meaning the files touched and any covered
  live runs, in the task result or as it grows. Do not ask per file.
- Ask again only when the change set materially grows beyond the declared scope
  or a limited field is reached.

## Autopilot

The host `autopilot` mode may run only while this protocol is active, and only
on work that is already agreed.

- On an unresolved choice, a limited field, or a never-changed rule, stop the
  affected task and report the specific blocker and what is needed.
- Do not ask and wait, and do not assume an answer. The user's absence is not
  permission to assume.
- Platform prompts remain under host control. This protocol cannot suppress them.
- A Refine discussion needs user answers and is not eligible.
