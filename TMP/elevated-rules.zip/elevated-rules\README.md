# Elevated rights: portable package

A project-agnostic protocol that lets the single task-owning agent work through
an agreed task with fewer prompts, under an explicit per-task `elevated rights`
command. It never widens the access policy, the operating rules, or host
controls.

## Contents

| File | Purpose |
| --- | --- |
| `Elevated-Rights-Protocol.md` | The protocol: who is elevated, activation, covered actions, limited fields, never-changed rules, prompting, autopilot. |
| `decisions.md` | Decision record R1–R9 with reasons, baseline, success checks and assumptions. |
| `integration.md` | Pointer texts for the glossary, operating rules, agents README, entry guide and docs index; adoption checklist. |

## Placeholders to fill

| Placeholder | Meaning |
| --- | --- |
| `<path to docs index>` | The project's documentation index. |
| `<path to operating rules>` | The contributor-wide agent operating rules. |
| `<path to access policy>` | The local access policy file (boundaries). |
| `<path to kit worker contract>` | The kit's worker contract, section `#temporary-elevated-rights-and-protected-actions`. |
| `<path to glossary>`, `<path to decisions.md>` | Project locations of those documents. |
| `<named validation commands>` | Exact non-mutating validations the operating rules allow without extra approval. |
| `<live runs through protected execution commands>` | Project-defined protected launchers, if any; remove the bullet if none. |
| `<governance files>` | Entry guide, operating rules, access policy, installed kit folder. |
| `<project failure gate>` | An approval step before failure fixes, if defined; remove the bullet if none. |

## Design summary

- Elevates one agent per task; workers keep the kit's per-worker grant.
- Conversation-only; never persisted, never rebuilt from a checkpoint.
- Limited fields always need specific authorization: deletion, installs and
  downloads, governance files, CI configuration, scope expansion and
  substantive decisions, failure-fix gates, secrets.
- Never changed: `never`/`user_only` rules, version-control mutations, secret
  and authentication sources, read-only sources, protected actions, remote
  writes, host platform prompts.
- Autopilot runs only with the protocol active and stops with a blocker report
  instead of asking or assuming.
- No change to the access policy or the release-managed kit is required.

## Open items for the source repository

- Whether host `autopilot` handles platform permission prompts is unverified.
- Whether the kit's worker contract should carry the optional cross-reference
  (see `integration.md`, section 6).
