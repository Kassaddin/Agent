# Integration: pointer texts

Adjust paths and names to the adopting project. The protocol itself is stated
once, in `Elevated-Rights-Protocol.md`; every other document only points to it.

## 1. Glossary entry (`Temporary elevated rights`)

> User consent, given per task by an explicit `elevated rights` command, that
> lets the single task-owning agent act on the declared task and resources
> without repeated `ask` prompts. It ends at task completion, revocation, or
> conversation end, and is never persisted. Named fields stay limited, and it is
> not administrator access, a persistent trust change, or permission to bypass
> prohibitions or protected-action approval. A worker's grant stays scoped to one
> identified worker and assignment.
>
> Sources: [Elevated Rights Protocol](<path>/Elevated-Rights-Protocol.md);
> [Worker rights and protected actions](<kit path>/orchestrator/references/worker-contract.md#temporary-elevated-rights-and-protected-actions).

## 2. Operating rules paragraph

Place it next to the explicit Orchestrator mode text. Also make sure the
Orchestrator consent sentence says it grants neither elevated rights nor
protected-action approval.

> A user's `elevated rights` command is defined by the
> [Elevated Rights Protocol](<path>/Elevated-Rights-Protocol.md): who it
> elevates, activation and duration, covered actions, limited fields, prompting,
> and autopilot behavior. A worker's grant stays scoped to one identified worker,
> assignment, and declared resource set, and never elevates the master. No grant
> overrides the prohibitions, read-only sources, or protected-action approval.

## 3. Agents README paragraph

> Temporary `elevated rights` are defined by the
> [Elevated Rights Protocol](./Elevated-Rights-Protocol.md). A worker's grant
> stays scoped to one identified worker's non-protected assignment, as in the
> [owning worker contract](<kit path>/orchestrator/references/worker-contract.md#temporary-elevated-rights-and-protected-actions).
> Protected actions need specific authorization. Activation alone does not grant
> implementation or unrestricted delegation.

## 4. Entry guide reading-map row

> | User `elevated rights` command or autopilot | [Elevated Rights Protocol](<path>/Elevated-Rights-Protocol.md). |

## 5. Documentation index row

> | Agent workflow | [Elevated Rights Protocol](<path>/Elevated-Rights-Protocol.md) | Task-scoped temporary rights for the single agent, limited fields, prompting, and autopilot behavior. |

## 6. Optional kit cross-reference

If the kit's worker contract should mention the project-level protocol, add one
sentence to its elevated-rights section:

> A project may define a separate, conversation-scoped protocol for the single
> task-owning agent; it does not widen a worker's grant, and a worker's grant
> does not elevate the master.

## Adoption checklist

1. Copy `Elevated-Rights-Protocol.md` and `decisions.md` into the project docs.
2. Replace every `<placeholder>` (see `README.md`).
3. Add the pointers above; do not restate the protocol elsewhere.
4. Confirm the access policy is unchanged and its validation still passes.
5. Confirm the operating rules do not contradict the limited fields.
