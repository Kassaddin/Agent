# Decisions: Temporary elevated rights protocol

Status: **MVP baseline.** This record holds accepted choices and reasons.

## Purpose and context

In the kit, `Temporary elevated rights` is defined only for one temporary
Orchestrator worker and explicitly does not elevate the single agent. The
protocol adds a project-level behavior so that the agent can work through an
agreed task with fewer prompts, usable with the host `autopilot` mode, while the
fields that must stay limited are named.

Goals:

1. Streamline the process with `autopilot` mode where applicable.
2. Prompt fewer times during implementation.
3. Separate `Temporary elevated rights` into a defined behavior protocol that
   lets the agent act within the project.
4. Define the fields that remain limited for the agent under that protocol.

## Established facts

- The kit's worker contract (release-managed, not editable in a project) scopes
  elevated rights to one worker, session and resource set, for non-protected
  actions, and states that it does not elevate the master.
- A project's operating rules mirror that scope and keep `never`, `user_only`,
  read-only sources, unavailable access, separate implementation approval and
  platform controls above any grant.
- The boundary contract pauses the whole task on a user question and forbids
  inferring assumed answers from the user's absence.
- The access policy is the persistent ceiling; the scoped-approval rule for
  execution that is not otherwise allowed lives in the operating rules.
- Neither the kit documents nor the boundary schema mention `autopilot`. It is a
  host mode, and its handling of platform permission prompts is not verified.

## Decisions

| ID | Decision | Reason |
| --- | --- | --- |
| R1 | The protocol elevates the **single task-owning agent** for the declared task and resources. Bundled Orchestrator workers keep the kit's per-worker grant; the protocol's limits apply to both. | Gives the agent the rights the user wants without changing the kit's worker contract. |
| R2 | Activation is an **explicit user `elevated rights` command per task**. It ends at task completion, on stop or revocation, or at conversation end. It lives in the conversation only, is never written to the access policy, is never rebuilt from a checkpoint, and is never inherited by a later task. | Keeps the grant temporary and visible, and keeps persistent trust in the reviewed access policy. |
| R3 | The protocol lives in a **dedicated document**. The operating rules keep a short pointer, and the glossary entry links to it. | One reader-facing home; the release-managed kit stays untouched. |
| R4 | **Autopilot** may run only with the protocol active, on already agreed work. On any unresolved choice or limited field the agent stops that task and reports the specific blocker. It neither asks nor assumes. | Unattended assumption would contradict the boundary contract; a blocker report keeps the user in control without a prompt. |
| R5 | Fields that **stay limited** (specific authorization still required): file or folder deletion; dependency installs and network downloads; governance files; CI and repository automation configuration; scope expansion and unresolved substantive decisions; project failure-fix gates (if defined) before plan approval; environment files, credentials and secrets. | Each can lose data, change trust or rules, or decide something that is the user's. |
| R6 | Always limited, independent of the protocol: `never` and `user_only` rules (including every version-control mutation), secret and authentication sources, version-control internals, read-only sources, the kit's protected actions, remote writes, and host platform prompts. | Existing rules; a protocol cannot widen them. |
| R7 | **Covered** (no prompt inside the declared task): reading, search, editing and creating files inside the declared task, the named validation commands, and live runs through the project's protected execution commands. | Cuts prompts for the work most often interrupted. See the assumptions below for the remaining safeguards. |
| R8 | **Prompt granularity:** one scoped authorization at activation. The agent then notifies the user of the change set without asking per file, and asks again only when the change set materially grows or a limited field is reached. | Meets the goal of fewer prompts and keeps the user informed. |
| R9 | **No change to the access policy.** The protocol is a conversation-scoped behavior defined in documents and can never widen the boundaries. | Boundaries stay the persistent ceiling. Any later amendment needs an Init review with a concrete preview. |

## MVP baseline

**Included**

- The protocol: subject, activation, duration, covered actions, limited fields,
  prompt granularity and autopilot behavior, as decided above.
- A statement of how the protocol relates to the kit's worker grant.

**Deferred**

- Verifying how the host `autopilot` handles platform permission prompts.
- Any persistent boundary rule.
- Any change to the release-managed kit.

## How success is assessed

- The protocol document states each of R1–R9 in one place, and the operating
  rules, the glossary and the agents README point to it without restating it.
- No sentence anywhere states or implies that the protocol overrides R6.
- The access-policy validation still passes, because the policy is unchanged.
- A Smokes audit of the changed documents shows no contradiction between the
  protocol, the operating rules and any project failure gate.

## Assumptions and unknowns

- **Live runs are covered (R7).** Where a project has a failure-fix gate, a
  mutating reproduction of a failure still waits for plan approval (R5). Whether
  live runs outside a failure diagnosis should stay bounded by a named command
  list is left to each project's drafting.
- **Host autopilot and platform prompts are unknown.** Project documents cannot
  suppress them. The protocol can only remove prompts caused by the project's
  own `ask` gates.
- **Shared environments.** Covered live runs can change shared state. The
  change-set notification (R8) is the visibility measure.
